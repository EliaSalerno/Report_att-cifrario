
#include <stdio.h>
#include <stdlib.h>

int main()
{
    char temp[4] = {"ciao"};
    char arr[26] = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    char *arr2;
    char *nuovo;
    char *caso;
    
    arr2 = (char*)malloc(26 * sizeof(char));
    nuovo = (char*)malloc(26 * sizeof(char));
    caso = (char*)malloc(26 * sizeof(char));
    
    // 1° FASE
    int i = 0;
    int x = 0;
    int indicePartenza = 5;
    for(i=0; i<= 26; i++){
        if(i + indicePartenza > 26){
            arr2[i] =  arr[x];
            x++;
        }
        else{
            arr2[i] = arr[i + indicePartenza];
        }
        printf("%c", arr2[i]);
    }
    
    
    // 2° FASE
    printf("\n\n");
    int k = 0;
    int g = 0;
    for(k=0;k<4;k++){
        for(g=0; g<26;g++){
            if(temp[k] == arr[g]){
                
                nuovo[k] = arr2[g];
                printf("%c", nuovo[k]);
            }
            
        }

    }
    printf("\n\n");
    // 3° FASE
    int p = 0;
    int u = 0;
    int y = 0;
    for(p=0;p<26;p++){
        for(u=0; u<4;u++){
            if(nuovo[u] + p <= 122){
                
                caso[u] = nuovo[u] + p;
                
            }
            else {
                caso[u] =  nuovo[u] + p - 26;
            
            }
            
        }
        printf("\n%s\n", caso);

    }
    
    
    
    return 0;
}



