/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/*Cifrario di cesare c'C( lo slittamento Inserire caratteri in un array 
*/
int
main ()
{
  char *arr = (char *) malloc (26 * sizeof (char));
  char *arrcambiato = (char *) malloc (26 * sizeof (char));
  char *stringa = (char *) malloc (1000);
  char *stringaNuova = (char *) malloc (1000);
  for (int i = 0; i < 26; i++)
    {
      arr[i] = 97 + i;
      printf ("%c", arr[i]);
    }
  int spostati;
  printf ("\nInserire lo spostamento\n");
  scanf ("%d", &spostati);
  for (int i = 0; i < 26; i++)
    {
      if ((97 + i + spostati) <= 122)
	arrcambiato[i] = 97 + spostati + i;
      else
	arrcambiato[i] = 97 + spostati + i - 26;
    }
  printf ("Inserisci la stringa\n");
  scanf ("%s", stringa);
  printf ("%s\n", arr);
  printf ("%s\n", stringa);
  for (int i = 0; i < 100; i++)
    {
      for (int k = 0; k < 26; k++)
	{
	  if (stringa[i] == arr[k])
	    {
	      stringaNuova[i] = arrcambiato[k];
	      k = 30;
	      break;
	    }
	  if (k == 25)
	    {
	      stringaNuova[i] = stringa[i];
	    }
	}
    }
  printf ("%s\n%s\n%s\n", stringaNuova, arr, arrcambiato);
  for (int cic = 0; cic < 26; cic++)
    {

      for (int i = 0; i < 26; i++)
	{
	  if ((97 + cic + i) <= 122)
	    arrcambiato[i] = 97 + cic + i;
	  else
	    arrcambiato[i] = 97 + i + cic - 26;
	}
      for (int luca = 0; luca < 100; luca++)
	{
	  for (int k = 0; k < 26; k++)
	    {
	      if (stringaNuova[luca] == arr[k])
		{
		  stringa[luca] = arrcambiato[k];
		  k = 30;
		  break;
		}
	      if (k == 25)
		{
		  stringa[luca] = stringaNuova[luca];
		}
	    }
	}
      printf ("%s\n", stringa);
    }
  return 0;
}

